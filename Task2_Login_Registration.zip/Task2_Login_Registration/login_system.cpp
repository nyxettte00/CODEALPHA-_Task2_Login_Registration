#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
using namespace std;

const string USERS_FILE = "users.txt";

// ---------- Helper Functions ----------

bool isUsernameExists(const string& username) {
    ifstream file(USERS_FILE);
    if (!file.is_open()) return false;

    string line, storedUser, storedPass;
    while (getline(file, line)) {
        size_t pos = line.find(':');
        if (pos != string::npos) {
            storedUser = line.substr(0, pos);
            if (storedUser == username) {
                file.close();
                return true;
            }
        }
    }
    file.close();
    return false;
}

bool isValidUsername(const string& username) {
    if (username.length() < 3) {
        cout << "Error: Username must be at least 3 characters long.\n";
        return false;
    }
    for (char c : username) {
        if (!isalnum(c) && c != '_') {
            cout << "Error: Username can only contain letters, numbers and underscore.\n";
            return false;
        }
    }
    return true;
}

bool isValidPassword(const string& password) {
    if (password.length() < 4) {
        cout << "Error: Password must be at least 4 characters long.\n";
        return false;
    }
    return true;
}

// ---------- Registration ----------

void registerUser() {
    string username, password;

    cout << "\n========== REGISTRATION ==========\n";
    cout << "Enter username: ";
    cin >> username;

    if (!isValidUsername(username)) return;

    if (isUsernameExists(username)) {
        cout << "Error: Username already exists. Please choose another.\n";
        return;
    }

    cout << "Enter password: ";
    cin >> password;

    if (!isValidPassword(password)) return;

    // Store credentials in file (username:password)
    ofstream file(USERS_FILE, ios::app);
    if (file.is_open()) {
        file << username << ":" << password << endl;
        file.close();
        cout << "Success: Registration completed successfully!\n";
    } else {
        cout << "Error: Unable to open users file for writing.\n";
    }
}

// ---------- Login ----------

void loginUser() {
    string username, password;

    cout << "\n============= LOGIN =============\n";
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    ifstream file(USERS_FILE);
    if (!file.is_open()) {
        cout << "Error: No users registered yet or file not found.\n";
        return;
    }

    string line, storedUser, storedPass;
    bool found = false;

    while (getline(file, line)) {
        size_t pos = line.find(':');
        if (pos != string::npos) {
            storedUser = line.substr(0, pos);
            storedPass = line.substr(pos + 1);

            if (storedUser == username && storedPass == password) {
                found = true;
                break;
            }
        }
    }
    file.close();

    if (found) {
        cout << "Success: Login successful! Welcome, " << username << "!\n";
    } else {
        cout << "Error: Invalid username or password.\n";
    }
}

// ---------- Main Menu ----------

int main() {
    int choice;

    do {
        cout << "\n==================================" << endl;
        cout << "   LOGIN & REGISTRATION SYSTEM" << endl;
        cout << "==================================" << endl;
        cout << "1. Register" << endl;
        cout << "2. Login" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                registerUser();
                break;
            case 2:
                loginUser();
                break;
            case 3:
                cout << "Exiting program. Goodbye!\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 3);

    return 0;
}
